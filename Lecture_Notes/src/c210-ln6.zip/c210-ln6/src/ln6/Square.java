/**
 *  Logan Mayfield
 */
package ln6;

/**
 * @author jlmayfield
 *
 */
public class Square implements Shape {

	private Rectangle asrec;
	
	/**
	 * Construct a unit square at the origin
	 * @throws none
	 * <dt><b> Preconditions </b><dd>
	 *   none
	 * <dt><b> Postconditions </b><dd>
	 *   none
	 * <dt><b> Complexity </b><dd>
	 *   constant
	 */
	public Square(){
		// unit square at the origin
		this.asrec = new Rectangle();
	}
	
	/**
	 * Construct a square by initializing location
	 * and side length
	 * @param pin the location of the upper left corner
	 * @param sideLength the length of the side
	 * @throws none
	 * <dt><b> Preconditions </b><dd>
	 *   sideLength > 0
	 * <dt><b> Postconditions </b><dd>
	 *   none
	 * <dt><b> Complexity </b><dd>
	 *   constant
	 */
	public Square(Loc pin, int sideLength){
		this.asrec = new Rectangle(pin,sideLength,sideLength);
		
	}
	
	/**
	 * Get the length of the side of this square
	 * @return the side length
	 * @throws none
	 * <dt><b> Preconditions </b><dd>
	 *   none
	 * <dt><b> Postconditions </b><dd>
	 *   none
	 * <dt><b> Complexity </b><dd>
	 *   constant
	 */
	public int getSideLength(){
		return this.asrec.getLength();
	}
	
	/**
	 * Set the side length of this Square to sideLength
	 * @param sideLength new side length
	 * @throws none
	 * <dt><b> Preconditions </b><dd>
	 *   none
	 * <dt><b> Postconditions </b><dd>
	 *   The side length of this is now sideLength
	 * <dt><b> Complexity </b><dd>
	 *   constant
	 */
	public void setSideLength(int sideLength){
		this.asrec.setLength(sideLength);
		this.asrec.setWidth(sideLength);
	}	
	
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((asrec == null) ? 0 : asrec.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Square other = (Square) obj;
		if (asrec == null) {
			if (other.asrec != null) {
				return false;
			}
		} else if (!asrec.equals(other.asrec)) {
			return false;
		}
		return true;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return String.format("Square [sideLength=%s, location=%s]",
				this.getSideLength(),this.getLocation());
	}

	/* (non-Javadoc)
	 * @see ln6.AbstractShape#area()
	 */
	@Override
	public double area() {
		return this.asrec.area();
	}

	/* (non-Javadoc)
	 * @see ln6.AbstractShape#isWithin(ln6.Loc)
	 */
	@Override
	public boolean isWithin(Loc l) {
		return this.asrec.isWithin(l);
	}

	/* (non-Javadoc)
	 * @see ln6.AbstractShape#boundingBox()
	 */
	@Override
	public Rectangle boundingBox() {		
		return this.asrec.boundingBox();
	}

	/*
	 * (non-Javadoc)
	 * @see ln6.Shape#distanceTo(ln6.Loc)
	 */
	@Override
	public double distanceTo(Loc l) {		
		return this.asrec.distanceTo(l);
	}

	/*
	 * (non-Javadoc)
	 * @see ln6.Shape#setLocation(ln6.Loc)
	 */
	@Override
	public void setLocation(Loc l) {
		this.asrec.setLocation(l);
		
	}

	/*
	 * (non-Javadoc)
	 * @see ln6.Shape#getLocation()
	 */
	@Override
	public Loc getLocation() {		
		return this.asrec.getLocation();
	}

}
