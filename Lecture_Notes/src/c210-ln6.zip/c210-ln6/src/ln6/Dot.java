/**
 * Logan Mayfield
 */
package ln6;

/**
 * @author jlmayfield
 *
 */
public class Dot extends AbstractShape implements Shape {

	/**
	 * Construct a Dot at the origin 
	 */
	public Dot() {
		super(new Loc(0,0));				
	}

	/**
	 * Construct a dot by initializing the location
	 * @param location the new location
	 * @throws none
	 * <dt><b>Preconditions</b><dd>
	 *   none   
	 * <dt><b>Postconditions</b><dd>
	 *   none
	 * <dt><b>Complexity</b><dd>
	 *   Constant
	 */
	public Dot(Loc location) {
		super(location);		
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {		
		return super.hashCode();		
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		return true;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Dot [location=");
		builder.append(getLocation());
		builder.append("]");
		return builder.toString();
	}

	/* (non-Javadoc)
	 * @see ln5.Shape#area()
	 */
	@Override
	public double area() {		
		return 0;
	}

	/* (non-Javadoc)
	 * @see ln5.Shape#boundingBox()
	 */
	@Override
	public Rectangle boundingBox() {
		return new Rectangle(this.getLocation(),0,0);
	}

	@Override
	public boolean isWithin(Loc l) {
		return this.getLocation().equals(l);
	}

	
}
