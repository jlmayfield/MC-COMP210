package ln6;

import static org.junit.Assert.*;

import org.junit.Test;

public class SquareTest {

	@Test
	public void testGetSideLength() {
		assertEquals(1,new Square().getSideLength());
		assertEquals(5,new Square(new Loc(),5).getSideLength());
	}

	@Test
	public void testSetSideLength() {
		Square s = new Square();
		assertEquals(1,s.getSideLength());
		s.setSideLength(15);
		assertEquals(15,s.getSideLength());
	}

	@Test
	public void testToString() {
		String expected = "Square [sideLength=1, location=Loc [row=0, col=0]]";
		assertEquals(expected,new Square().toString());
	}

	@Test
	public void testArea() {
		Square s = new Square(new Loc(),5);
		assertEquals(25.0,s.area(),0.00000001);
	}

	@Test
	public void testIsWithin() {
		Square s = new Square(new Loc(0,0),5);
		assertTrue(s.isWithin(new Loc(2,2)));
		assertFalse(s.isWithin(new Loc(25,25)));		
	}

	@Test
	public void testBoundingBox() {
		assertEquals(new Rectangle(),new Square().boundingBox());
	}

	@Test
	public void testDistanceTo() {
		assertEquals(1.0,new Square().distanceTo(new Loc(0,1)),0.0000001);
	}

	@Test
	public void testSetLocation() {
		Square s = new Square(new Loc(2,2),5);
		assertEquals(new Loc(2,2),s.getLocation());
		s.setLocation(new Loc(2,5));
		assertEquals(new Loc(2,5),s.getLocation());
	}

	@Test
	public void testGetLocation() {
		assertEquals(new Loc(),new Square().getLocation());
		assertEquals(new Loc(2,5),new Square(new Loc(2,5),3).getLocation());
	}

}
