/**
 * Logan Mayfield
 */

package ln6;

public class Loc {

	/**
	 * The row index of the location
	 */
	private int row;
	/**
	 * The column index of the location
	 */
	private int col;		
	
	/**
	 * Construct a location at the origin
	 * @throws none
	 * <dt><b>Preconditions</b><dd>
	 *   none
	 * <dt><b>Postconditions</b><dd>
	 *   none	 
	 * <dt><b>Complexity</b><dd>
	 *   constant
	 */
	public Loc() {
		super();
		this.row = 0;
		this.col = 0;		
	}

	/**
	 * Construct the location (row,col)
	 * @param row
	 * @param col
	 * @throws none
	 * <dt><b>Preconditions</b><dd>	 
	 *     none
	 * <dt><b>Postconditions</b><dd>
	 *    this is now the location for (row,col)
	 * <dt><b>Complexity</b><dd>
	 *    constant         
	 */
	public Loc(int row, int col) {
		super();
		this.row = row;
		this.col = col;
		
	}
	
	/**
	 * Row selector	  
	 * @return the row
	 * @throws none
	 * <dt><b>Preconditions</b><dd>
	 *    none
	 * <dt><b>Postconditions</b><dd>
	 *    none
	 * <dt><b>Complexity</b><dd>
	 *    constant   
	 */
	public int getRow() {
		return row;
	}
	
	/**
	 * Set the row of this location
	 * @param row the row to set
	 * @return none
	 * <dt><b>Preconditions</b><dd>
	 *   none	
	 * <dt><b>Postconditions</b><dd>
	 *   none
	 * <dt><b>Complexity</b><dd>
	 *   none	     
	 */
	public void setRow(int row) {
		this.row = row;
	}
	
	/**
	 * Select the column index for the location
	 * @return the col
	 * @throws none
	 * <dt><b>Preconditions</b><dd>
	 *   none	
	 * <dt><b>Postconditions</b><dd>
	 *   none
	 * <dt><b>Complexity</b><dd>
	 *   none	     
	 */
	public int getCol() {
		return col;
	}
	
	/**
	 * Set the column of this location
	 * @param col the col to set
	 * @return none
	 * <dt><b>Preconditions</b><dd>
	 *   none	
	 * <dt><b>Postconditions</b><dd>
	 *   none
	 * <dt><b>Complexity</b><dd>
	 *   none	     
	 */
	public void setCol(int col) {
		this.col = col;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + col;
		result = prime * result + row;
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Loc other = (Loc) obj;
		if (col != other.col)
			return false;
		if (row != other.row)
			return false;
		return true;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Loc [row=" + row + ", col=" + col + "]";
	}

	/**
	 * Compute the distance from this to that
	 * @param that another location
	 * @return the distance from this to that
	 * @throws none
	 * <dt><b>Preconditions</b><dd>
	 *    none
	 * <dt><b>Postconditions</b><dd>
	 *    none
	 * <dt><b>Complexity</b><dd>
	 *    Constant
	 */
	public double distanceTo(Loc that) {
		return Math.sqrt(
				Math.pow(this.row - that.row,2) + 
				Math.pow(this.col - that.col,2));
				
	}
	
	
}
