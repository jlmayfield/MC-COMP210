/**
 * Logan Mayfield
 */
package ln6;

/**
 * @author jlmayfield
 *
 */
public class Circle extends AbstractShape implements Shape{

	// circle's radius
	private int radius;
	
	
	/**
	 * Construct a unit circle at the origin
	 * @throws none
	 * <dt><b>Precondition</b><dd>
	 *    none
	 * <dt><b>Postcondition</b><dd>
	 *    none
	 * <dt><b>Complexity</b><dd>
	 *    Constant
	 */
	public Circle() {
		super(new Loc(0,0));		
		this.radius = 1;	
	}

	/**
	 * Construct a circle by initializing center point and
	 *  radius	   
	 * @param center
	 * @param radius
	 * @throws none
	 * <dt><b>Precondition</b><dd>
	 *    none
	 * <dt><b>Postcondition</b><dd>
	 *    none
	 * <dt><b>Complexity</b><dd>
	 *    Constant
	 */
	public Circle(Loc center, int radius) {
		super(center);		
		this.radius = radius;
	}

	/**
	 * Get the radius of this circle 
	 * @return the radius 
	 * @throws none
	 * <dt><b>Precondition</b><dd>
	 *    none
	 * <dt><b>Postcondition</b><dd>
	 *    none
	 * <dt><b>Complexity</b><dd>
	 *    Constant
	 */
	public int getRadius() {
		return radius;
	}

	/**
	 * Set the radius of this circle
	 * @param radius the new radius 
	 * @return none 
	 * @throws none
	 * <dt><b>Precondition</b><dd>
	 *    none
	 * <dt><b>Postcondition</b><dd>
	 *    the radius of this is now radius
	 * <dt><b>Complexity</b><dd>
	 *    Constant
	 */
	public void setRadius(int radius) {
		this.radius = radius;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + radius;
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Circle other = (Circle) obj;
		if (radius != other.radius) {
			return false;
		}
		return true;
	}

	
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Circle [radius=");
		builder.append(radius);
		builder.append(", center=");
		builder.append(getLocation());
		builder.append("]");
		return builder.toString();
	}

	/* (non-Javadoc)
	 * @see ln5.Shape#area()
	 */
	@Override
	public double area() {
		return Math.PI * this.radius * this.radius;
	}

	/* (non-Javadoc)
	 * @see ln5.Shape#isWithin(ln5.Loc)
	 */
	@Override
	public boolean isWithin(Loc l) {
		return this.getLocation().distanceTo(l) <= this.radius;
	}

	/* (non-Javadoc)
	 * @see ln5.Shape#boundingBox()
	 */
	@Override
	public Rectangle boundingBox() {
		Loc bb_upRight = new Loc();
		Loc center = this.getLocation();
		bb_upRight.setRow(center.getRow()-this.radius);
		bb_upRight.setCol(center.getCol()-this.radius);
		return new Rectangle(bb_upRight,2*this.radius,2*this.radius);
	}

}
