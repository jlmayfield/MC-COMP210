/*
 * Logan Mayfield
 */
package ln6;

import static org.junit.Assert.*;

import org.junit.Test;

import ln6.Circle;
import ln6.Dot;
import ln6.Loc;
import ln6.Rectangle;

public class CircleTest {
	
	// 12 bit precision
	static final double DELTA = Math.pow(2, -12);
	
	@Test
	public void testHashCode() {
		Circle acirc = new Circle();
		assertEquals((31*31+31)*31 + 1 ,acirc.hashCode());
	}

	@Test
	public void testGetLocation() {
		assertEquals(new Loc(0,0),new Circle().getLocation());
	}

	@Test
	public void testSetLocation() {
		Circle acirc = new Circle();
		assertEquals(new Loc(0,0),acirc.getLocation());
		acirc.setLocation(new Loc(3,2));
		assertEquals(new Loc(3,2),acirc.getLocation());
	}

	@Test
	public void testGetRadius() {
		assertEquals(1,new Circle().getRadius());
	}

	@Test
	public void testSetRadius() {
		Circle acirc = new Circle();
		assertEquals(1,acirc.getRadius());
		acirc.setRadius(3);
		assertEquals(3,acirc.getRadius());
	}

	@Test
	public void testEqualsObject() {
		Circle acirc = new Circle();
		assertEquals(acirc,acirc);
		assertEquals(acirc,new Circle());
		
		assertFalse(acirc.equals(null));
		assertFalse(acirc.equals(new Dot()));
		assertFalse(acirc.equals(2));
		assertFalse(acirc.equals(new Circle(new Loc(1,2),1)));
		assertFalse(acirc.equals(new Circle(new Loc(0,0),2)));
	}

	@Test
	public void testToString() {
		String expected = "Circle [radius=1, center=Loc [row=0, col=0]]";
		assertEquals(expected,new Circle().toString());
	}

	@Test
	public void testArea() {
		assertEquals(Math.PI,new Circle().area(),DELTA);
		assertEquals(Math.PI*4,new Circle(new Loc(1,2),2).area(),DELTA);		
	}

	@Test
	public void testDistanceTo() {
		
		assertEquals(0.0, new Circle().distanceTo(new Loc()),DELTA);
		assertEquals(Math.sqrt(2.0), new Circle().distanceTo(new Loc(1,1)),DELTA );
		assertEquals(5.0, new Circle().distanceTo(new Loc(4,3)),DELTA);
	}

	@Test
	public void testIsWithin() {
		assertFalse(new Circle().isWithin(new Loc(3,5)));
		assertTrue(new Circle(new Loc(1,1),5).isWithin(new Loc()));
		assertTrue(new Circle(new Loc(1,1),5).isWithin(new Loc(1,1)));
	}

	@Test
	public void testBoundingBox() {
		assertEquals(new Rectangle(new Loc(0,0),2,2),
				new Circle(new Loc(1,1),1).boundingBox());
	}

	@Test
	public void testMoveTo() {
		Circle acirc = new Circle();
		assertEquals(new Loc(),acirc.getLocation());
		acirc.setLocation(new Loc(2,3));
		assertEquals(new Loc(2,3),acirc.getLocation());
	}

}
