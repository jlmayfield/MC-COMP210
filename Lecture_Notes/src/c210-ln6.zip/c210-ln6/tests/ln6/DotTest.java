package ln6;

import static org.junit.Assert.*;

import org.junit.Test;

import ln6.Dot;
import ln6.Loc;
import ln6.Rectangle;

public class DotTest {

	static final double DELTA = Math.pow(2, -12);
	
	@Test
	public void testHashCode() {
		assertEquals(31+31*31,new Dot().hashCode());
	}

	@Test
	public void testGetLocation() {
		Dot adot = new Dot();
		assertEquals(new Loc(0,0),adot.getLocation());
		assertEquals(new Loc(2,3),new Dot(new Loc(2,3)).getLocation());
	}

	@Test
	public void testSetLocation() {
		Dot adot = new Dot();
		assertEquals(new Loc(0,0),adot.getLocation());
		adot.setLocation(new Loc(5,2));
		assertEquals(new Loc(5,2),adot.getLocation());
	}

	@Test
	public void testEqualsObject() {
		Dot adot = new Dot(new Loc(3,2));
		assertEquals(adot,adot);
		assertEquals(new Dot(),new Dot());
		assertEquals(adot,new Dot(new Loc(3,2)));
		
		assertFalse(new Dot().equals(null));
		assertFalse(new Dot().equals(new Rectangle()));
		assertFalse(new Dot().equals(3.14159));
		assertFalse(new Dot(new Loc(3,2)).equals(new Loc(3,2)));
	}

	@Test
	public void testToString() {
		assertEquals("Dot [location=Loc [row=2, col=3]]",
				new Dot(new Loc(2,3)).toString());
	}

	@Test
	public void testArea() {
		assertEquals(0,new Dot().area(),DELTA);
		assertEquals(0,new Dot(new Loc(4,2)).area(),DELTA);
	}

	@Test
	public void testDistanceTo() {
		assertEquals(0.0,new Dot().distanceTo(new Loc()),DELTA);
		assertEquals(Math.sqrt(2.0),new Dot().distanceTo(new Loc(1,1)),DELTA);
		assertEquals(5.0,new Dot().distanceTo(new Loc(4,3)),DELTA);
	}

	@Test
	public void testIsWithin() {
		assertFalse(new Dot().isWithin(new Loc(1,1)));
		assertTrue(new Dot().isWithin(new Loc()));		
	}

	@Test
	public void testBoundingBox() {
		assertEquals(new Rectangle(new Loc(0,0),0,0),new Dot().boundingBox());
		assertEquals(new Rectangle(new Loc(3,4),0,0),
				new Dot(new Loc(3,4)).boundingBox());
	}

	@Test
	public void testMoveTo() {
		Dot adot = new Dot();
		assertEquals(new Loc(0,0),adot.getLocation());
		adot.setLocation(new Loc(3,6));
		assertEquals(new Loc(3,6),adot.getLocation());	
		
	}

}
