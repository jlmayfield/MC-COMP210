package ln4;

import static org.junit.Assert.*;

import org.junit.Test;

public class LocTest {

	final static double DELTA = Math.pow(2, -12);
	
	@Test
	public void testHashCode() {
		assertEquals(31*31,new Loc().hashCode());
		assertEquals((31+3)*31 + 4, new Loc(4,3).hashCode());
	}

	@Test
	public void testGetRow() {
		Loc aloc = new Loc();
		assertEquals(0,aloc.getRow());
		aloc = new Loc(5,0);
		assertEquals(5,aloc.getRow());
	}

	@Test
	public void testSetRow() {
		Loc aloc = new Loc();
		
		assertEquals(0,aloc.getRow());
		aloc.setRow(5);		
		assertEquals(5,aloc.getRow());
	}

	@Test
	public void testGetCol() {
		Loc aloc = new Loc();
		assertEquals(0,aloc.getCol());
		aloc = new Loc(4,7);
		assertEquals(7,aloc.getCol());
	}

	@Test
	public void testSetCol() {		
		Loc aloc = new Loc();
		assertEquals(0,aloc.getCol());
		aloc.setCol(7);
		assertEquals(7,aloc.getCol());
	}

	@Test
	public void testEqualsObject() {
		Loc aloc = new Loc();
		assertEquals(aloc,aloc);
		
		assertEquals(new Loc(),new Loc());
		assertEquals(new Loc(),new Loc(0,0));
		assertEquals(new Loc(1,3),new Loc(1,3));
				
		assertFalse(new Loc().equals(null));
		assertFalse(new Loc(1,1).equals(5));		
		assertFalse(new Loc().equals(new Loc(1,1)));
		assertFalse(new Loc(1,3).equals(new Loc(1,2)));
		assertFalse(new Loc(1,3).equals(new Loc(2,3)));		
	}

	@Test
	public void testToString() {
		String expected = "Loc [row=0, col=0]";
		assertEquals(expected,new Loc().toString());
		expected = "Loc [row=3, col=8]";
		assertEquals(expected,new Loc(3,8).toString());
	}

	@Test
	public void testDistantceTo(){
		assertEquals(0.0,new Loc().distanceTo(new Loc()),DELTA);
		assertEquals(Math.sqrt(2.0),new Loc(1,1).distanceTo(new Loc()),DELTA);
		assertEquals(5.0,new Loc(4,3).distanceTo(new Loc()),DELTA);
		
		
	}
	
	
	
	
	
}
