package ln4;

import static org.junit.Assert.*;

import org.junit.Test;

public class RectangleTest {

	static final double DELTA = Math.pow(2, -12);
	
	@Test
	public void testHashCode() {
		int baseHash = (((31 + 1)*31) + 31*31)* 31 + 1;
		assertEquals(baseHash,new Rectangle().hashCode());
	}

	@Test
	public void testGetUpperLeft() {
		assertEquals(new Loc(),new Rectangle().getUpperLeft());
		assertEquals(new Loc(3,1),
				new Rectangle(new Loc(3,1),2,5).getUpperLeft());
	}

	@Test
	public void testSetUpperRight() {
		Rectangle arec = new Rectangle();
		assertEquals(new Loc(0,0),arec.getUpperLeft());
		arec.setUpperLeft(new Loc(3,7));
		assertEquals(new Loc(3,7),arec.getUpperLeft());		
	}

	@Test
	public void testGetWidth() {
		assertEquals(1,new Rectangle().getWidth());
		assertEquals(2,new Rectangle(new Loc(3,5),2,4).getWidth());
	}

	@Test
	public void testSetWidth() {
		Rectangle arec = new Rectangle();
		assertEquals(1,arec.getWidth());
		arec.setWidth(19);
		assertEquals(19,arec.getWidth());
	}

	@Test
	public void testGetLength() {
		assertEquals(1,new Rectangle().getLength());
		assertEquals(4,new Rectangle(new Loc(3,5),2,4).getLength());
	}

	@Test
	public void testSetLength() {
		Rectangle arec = new Rectangle();
		assertEquals(1,arec.getLength());
		arec.setLength(17);
		assertEquals(17,arec.getLength());
	}

	@Test
	public void testEqualsObject() {
		Rectangle arec = new Rectangle();	
		assertEquals(arec,arec);
		assertEquals(arec,new Rectangle());
		
		assertFalse(arec.equals(null));
		assertFalse(arec.equals(5));
		assertFalse(arec.equals(new Dot()));
		assertFalse(arec.equals(
				new Rectangle(new Loc(0,1),1,1)));
		assertFalse(arec.equals(
				new Rectangle(new Loc(0,0),2,1)));
		assertFalse(arec.equals(
				new Rectangle(new Loc(0,0),1,2)));
		
	}

	@Test
	public void testToString() {
		String expected = "Rectangle [";
		expected += "upperRight=Loc [row=0, col=0], ";
		expected += "width=3, length=8]";
		Rectangle arec = new Rectangle(new Loc(0,0),3,8);
		assertEquals(expected,arec.toString());
	}

	@Test
	public void testArea() {
		assertEquals(1.0,new Rectangle().area(),DELTA);
		assertEquals(10.0,
				new Rectangle(new Loc(1,1),5,2).area(),
				DELTA);
	}

	@Test
	public void testDistanceTo() {
		assertEquals(0.0,new Rectangle().distanceTo(new Loc()),DELTA);
		assertEquals(Math.sqrt(2.0),new Rectangle().distanceTo(new Loc(1,1)),DELTA);
		assertEquals(5.0,new Rectangle().distanceTo(new Loc(4,3)),DELTA);
	}

	@Test
	public void testIsWithin() {
		assertTrue(new Rectangle().isWithin(new Loc(0,0)));
		assertTrue(new Rectangle().isWithin(new Loc(1,1)));
		assertTrue(new Rectangle().isWithin(new Loc(0,1)));
		assertTrue(new Rectangle().isWithin(new Loc(1,0)));
		assertFalse(new Rectangle().isWithin(new Loc(2,1)));
	}

	@Test
	public void testBoundingBox() {
		assertEquals(new Rectangle(),new Rectangle().boundingBox());		
	}
	
	@Test
	public void testMoveTo() {
		Rectangle arec = new Rectangle();
		assertEquals(new Loc(),arec.getUpperLeft());
		arec.moveTo(new Loc(4,8));
		assertEquals(new Loc(4,8),arec.getUpperLeft());		
	}

}
