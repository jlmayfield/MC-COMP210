/**
 * Logan Mayfield
 */
package ln4;

/**
 * @author jlmayfield
 *
 */
public class Rectangle implements Shape {

	// Location of the upper right corner of the rectangle
	private Loc upperLeft;
	// The number of columns spanned
	private int width;
	// The number of rows spanned
	private int length;	
	
	
	
	/**
	 * Constructs a unit square at 0,0
	 * @throws none
	 * <dt><b>Preconditions</b><dd>
	 *    none
	 * <dt><b>Postconditions</b><dd>
	 *    none
	 * <dt><b>Complexity</b><dd>
	 *    Constant     
	 */
	public Rectangle() {
		super();
		this.upperLeft = new Loc(0,0);
		this.length = 1;
		this.width = 1;
	}

	/**
	 * Construct a rectangle by initializing location, width,
	 * and length
	 * @param upperLeft
	 * @param width
	 * @param length
	 * @throws none
	 * <dt><b>Preconditions</b><dd>
	 *   none
	 * <dt><b>Postconditions</b><dd>
	 *   none
	 * <dt><b>Complexity</b><dd>
	 *   Constant
	 */
	public Rectangle(Loc upperLeft, int width, int length) {
		super();
		this.upperLeft = upperLeft;
		this.width = width;
		this.length = length;
	}

	/**
	 * Get the location of the Rectangle's upper right corner
	 * @return the upperRight
	 * <dt><b>Preconditions</b><dd>
	 *   none
	 * <dt><b>Postconditions</b><dd>
	 *   none
	 * <dt><b>Complexity</b><dd>
	 *   Constant
	 */
	public Loc getUpperLeft() {
		return upperLeft;
	}

	/**
	 * Set the location of the Rectangle's upper right corner
	 * @param upperRight the new upper right corner
	 * @return none
	 * <dt><b>Preconditions</b><dd>
	 *   none
	 * <dt><b>Postconditions</b><dd>
	 *   this rectangle is now located at upperRight
	 * <dt><b>Complexity</b><dd>
	 *   Constant
	 */
	public void setUpperLeft(Loc upperLeft) {
		this.upperLeft = upperLeft;
	}

	/**
	 * Get this Rectangle's width 
	 * @return the width of the Rectangle
	 * <dt><b>Preconditions</b><dd>
	 *   none
	 * <dt><b>Postconditions</b><dd>
	 *   none
	 * <dt><b>Complexity</b><dd>
	 *   Constant
	 */
	public int getWidth() {
		return width;
	}

	/**
	 * Set this Rectangle's width to width
	 * @param width the new width
	 * @return none
	 * <dt><b>Preconditions</b><dd>
	 *   none
	 * <dt><b>Postconditions</b><dd>
	 *   this rectangle is now width column wide
	 * <dt><b>Complexity</b><dd>
	 *   Constant
	 */
	public void setWidth(int width) {
		this.width = width;
	}

	/**
	 * Get this Rectangle's length 
	 * @return the length of the Rectangle
	 * <dt><b>Preconditions</b><dd>
	 *   none
	 * <dt><b>Postconditions</b><dd>
	 *   none
	 * <dt><b>Complexity</b><dd>
	 *   Constant
	 */
	public int getLength() {
		return length;
	}

	/**
	 * Set this Rectangle's length to length
	 * @param width the new width
	 * @return none
	 * <dt><b>Preconditions</b><dd>
	 *   none
	 * <dt><b>Postconditions</b><dd>
	 *   this rectangle is now length rows long
	 * <dt><b>Complexity</b><dd>
	 *   Constant
	 */
	public void setLength(int length) {
		this.length = length;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + length;
		result = prime * result + ((upperLeft == null) ? 0 : upperLeft.hashCode());
		result = prime * result + width;
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Rectangle other = (Rectangle) obj;
		if (length != other.length)
			return false;
		if (upperLeft == null) {
			if (other.upperLeft != null)
				return false;
		} else if (!upperLeft.equals(other.upperLeft))
			return false;
		if (width != other.width)
			return false;
		return true;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Rectangle [upperRight=" + upperLeft + ", width=" + width + ", length=" + length + "]";
	}

	/*
	 * (non-Javadoc)
	 * @see ln4.Shape#area()
	 */
	@Override
	public double area() {
		return this.length * this.width;
	}

	/* (non-Javadoc)
	 * @see ln4.Shape#distanceTo(ln4.Loc)
	 */
	@Override
	public double distanceTo(Loc l) {		
		return this.upperLeft.distanceTo(l);
	}

	/* (non-Javadoc)
	 * @see ln4.Shape#isWithin(ln4.Loc)
	 */
	@Override
	public boolean isWithin(Loc l) {
		return 
		  this.upperLeft.getRow() <= l.getRow() &&
		  this.upperLeft.getRow() + this.length >= l.getRow() &&
		  this.upperLeft.getCol() <= l.getCol() &&
		  this.upperLeft.getCol() + this.width >= l.getCol();			
	}

	/* (non-Javadoc)
	 * @see ln4.Shape#boundingBox()
	 */
	@Override
	public Rectangle boundingBox() {
		return new Rectangle(
				new Loc(this.upperLeft.getRow(),
						this.upperLeft.getCol()),
				this.width,this.length);
	}

	/* (non-Javadoc)
	 * @see ln4.Shape#moveTo(ln4.Loc)
	 * 
	 */
	@Override
	public void moveTo(Loc l) {
		this.setUpperLeft(l);

	}

}
