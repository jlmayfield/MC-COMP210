/**
 * Logan Mayfield
 */
package ln4;

public interface Shape {

	/**
	 * Compute the area of the shape
	 * @return the area 
	 * @throws none
	 * <dt><b>Preconditions</b><dd>
	 * 		none
	 * <dt><b>Postconditions</b><dd>
	 * 		none 
	 */
	double area();
	
	/**
	 * Compute the distance to location l
	 * @param l
	 * @return distance to l
	 * @throws none
	 * <dt><b>Preconditions</b><dd>
	 * 	  none
	 * <dt><b>Postconditions</b><dd>
	 *    none	     
	 */
	double distanceTo(Loc l);
	
	/**
	 * Determine if location l falls within this shape
	 * @param l
	 * @return true if l is within this
	 * @throws none
	 * <dt><b>Preconditions</b><dd>
	 * 	  none
	 * <dt><b>Postconditions</b><dd>
	 *    none 
	 */
	boolean isWithin(Loc l);
	
	/**
	 * Compute the bounding box of this as a Rectangle
	 * @return the bounding box of this
	 * @this none
	 * <dt><b>Preconditions</b><dd>
	 *     none
	 * <dt><b>Postconditions</b><dd>    
	 */
	Rectangle boundingBox();
	
	/**
	 * Change location of this to l 
	 * @param l
	 * @return none
	 * @throws none
	 * <dt><b>Preconditions</b><dd>
	 *    none
	 * <dt><b>Postconditions</b><dd>
	 *    The location of this is now l
	 */
	void moveTo(Loc l);
	
		
}
