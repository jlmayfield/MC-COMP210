/**
 * Logan Mayfield
 */
package ln4;

/**
 * @author jlmayfield
 *
 */
public class Dot implements Shape {

	// location of the dot
	private Loc location;
	
	/**
	 * Construct a Dot at the origin 
	 */
	public Dot() {
		super();
		this.location = new Loc(0,0);		
	}

	/**
	 * Construct a dot by initializing the location
	 * @param location the new location
	 * @throws none
	 * <dt><b>Preconditions</b><dd>
	 *   none   
	 * <dt><b>Postconditions</b><dd>
	 *   none
	 * <dt><b>Complexity</b><dd>
	 *   Constant
	 */
	public Dot(Loc location) {
		super();
		this.location = location;
	}

	/**
	 * Get the location of this dot
	 * @return the location
	 * @throws none
	 * <dt><b>Preconditions</b><dd>
	 *  none   
	 * <dt><b>Postconditions</b><dd>
	 *  none
	 * <dt><b>Complexity</b><dd>
	 *  Constant
	 */
	public Loc getLocation() {
		return location;
	}

	/**
	 * Set the location of this location
	 * @param location the location to set
	 * @return none
	 * @throws none
	 * <dt><b>Preconditions</b><dd>
	 *  none   
	 * <dt><b>Postconditions</b><dd>
	 *  This dot is not located at location
	 * <dt><b>Complexity</b><dd>
	 *  Constant
	 */
	public void setLocation(Loc location) {
		this.location = location;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((location == null) ? 0 : location.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Dot other = (Dot) obj;
		if (location == null) {
			if (other.location != null) {
				return false;
			}
		} else if (!location.equals(other.location)) {
			return false;
		}
		return true;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Dot [location=" + location + "]";
	}

	/* (non-Javadoc)
	 * @see ln4.Shape#area()
	 */
	@Override
	public double area() {		
		return 0;
	}

	/* (non-Javadoc)
	 * @see ln4.Shape#distanceTo(ln4.Loc)
	 */
	@Override
	public double distanceTo(Loc l) {
		return l.distanceTo(this.location);
	}

	/* (non-Javadoc)
	 * @see ln4.Shape#isWithin(ln4.Loc)
	 */
	@Override
	public boolean isWithin(Loc l) {
		return this.location.equals(l);
	}

	/* (non-Javadoc)
	 * @see ln4.Shape#boundingBox()
	 */
	@Override
	public Rectangle boundingBox() {
		return new Rectangle(this.location,0,0);
	}

	/* (non-Javadoc)
	 * @see ln4.Shape#moveTo(ln4.Loc)
	 */
	@Override
	public void moveTo(Loc l) {
		this.setLocation(l);
	}

}
