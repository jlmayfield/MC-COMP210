/**
 * Logan Mayfield
 */
package ln4;

/**
 * @author jlmayfield
 *
 */
public class Circle implements Shape {

	// center of the circle
	private Loc center;
	// circle's radius
	private int radius;
	
	
	/**
	 * Construct a unit circle at the origin
	 * @throws none
	 * <dt><b>Precondition</b><dd>
	 *    none
	 * <dt><b>Postcondition</b><dd>
	 *    none
	 * <dt><b>Complexity</b><dd>
	 *    Constant
	 */
	public Circle() {
		super();
		this.center = new Loc(0,0);
		this.radius = 1;	
	}

	/**
	 * Construct a circle by initializing center point and
	 *  radius	   
	 * @param center
	 * @param radius
	 * @throws none
	 * <dt><b>Precondition</b><dd>
	 *    none
	 * <dt><b>Postcondition</b><dd>
	 *    none
	 * <dt><b>Complexity</b><dd>
	 *    Constant
	 */
	public Circle(Loc center, int radius) {
		super();
		this.center = center;
		this.radius = radius;
	}

	/**
	 * Get the center location of this circle 
	 * @return the center location
	 * @throws none
	 * <dt><b>Precondition</b><dd>
	 *    none
	 * <dt><b>Postcondition</b><dd>
	 *    none
	 * <dt><b>Complexity</b><dd>
	 *    Constant
	 */
	public Loc getCenter() {
		return center;
	}

	/**
	 * Set the center location of this circle
	 * @param center the new center location 
	 * @return none 
	 * @throws none
	 * <dt><b>Precondition</b><dd>
	 *    none
	 * <dt><b>Postcondition</b><dd>
	 *    the center location this is now center
	 * <dt><b>Complexity</b><dd>
	 *    Constant
	 */
	public void setCenter(Loc center) {
		this.center = center;
	}

	/**
	 * Get the radius of this circle 
	 * @return the radius 
	 * @throws none
	 * <dt><b>Precondition</b><dd>
	 *    none
	 * <dt><b>Postcondition</b><dd>
	 *    none
	 * <dt><b>Complexity</b><dd>
	 *    Constant
	 */
	public int getRadius() {
		return radius;
	}

	/**
	 * Set the radius of this circle
	 * @param radius the new radius 
	 * @return none 
	 * @throws none
	 * <dt><b>Precondition</b><dd>
	 *    none
	 * <dt><b>Postcondition</b><dd>
	 *    the radius of this is now radius
	 * <dt><b>Complexity</b><dd>
	 *    Constant
	 */
	public void setRadius(int radius) {
		this.radius = radius;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((center == null) ? 0 : center.hashCode());
		result = prime * result + radius;
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Circle other = (Circle) obj;
		if (center == null) {
			if (other.center != null)
				return false;
		} else if (!center.equals(other.center))
			return false;
		if (radius != other.radius)
			return false;
		return true;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Circle [center=" + center + ", radius=" + radius + "]";
	}

	/* (non-Javadoc)
	 * @see ln4.Shape#area()
	 */
	@Override
	public double area() {
		return Math.PI * this.radius * this.radius;
	}

	/* (non-Javadoc)
	 * @see ln4.Shape#distanceTo(ln4.Loc)
	 */
	@Override
	public double distanceTo(Loc l) {
		return this.center.distanceTo(l);
	}

	/* (non-Javadoc)
	 * @see ln4.Shape#isWithin(ln4.Loc)
	 */
	@Override
	public boolean isWithin(Loc l) {
		return this.center.distanceTo(l) <= this.radius;
	}

	/* (non-Javadoc)
	 * @see ln4.Shape#boundingBox()
	 */
	@Override
	public Rectangle boundingBox() {
		Loc bb_upRight = new Loc();
		bb_upRight.setRow(this.center.getRow()-this.radius);
		bb_upRight.setCol(this.center.getCol()-this.radius);
		return new Rectangle(bb_upRight,2*this.radius,2*this.radius);
	}

	/* (non-Javadoc)
	 * @see ln4.Shape#moveTo(ln4.Loc)
	 */
	@Override
	public void moveTo(Loc l) {
		this.setCenter(l);
	}

}
