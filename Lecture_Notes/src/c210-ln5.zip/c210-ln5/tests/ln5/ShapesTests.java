package ln5;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ CircleTest.class, DotTest.class, RectangleTest.class, LocTest.class })
public class ShapesTests {

}
