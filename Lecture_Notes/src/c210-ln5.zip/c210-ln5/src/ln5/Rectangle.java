/**
 * Logan Mayfield
 */
package ln5;

/**
 * @author jlmayfield
 *
 */
public class Rectangle extends AbstractShape implements Shape {

	// The number of columns spanned
	private int width;
	// The number of rows spanned
	private int length;	
	
	
	
	/**
	 * Constructs a unit square at 0,0
	 * @throws none
	 * <dt><b>Preconditions</b><dd>
	 *    none
	 * <dt><b>Postconditions</b><dd>
	 *    none
	 * <dt><b>Complexity</b><dd>
	 *    Constant     
	 */
	public Rectangle() {
		super(new Loc(0,0));		
		this.length = 1;
		this.width = 1;
	}

	/**
	 * Construct a rectangle by initializing location, width,
	 * and length
	 * @param upperLeft
	 * @param width
	 * @param length
	 * @throws none
	 * <dt><b>Preconditions</b><dd>
	 *   length,width >= 0
	 * <dt><b>Postconditions</b><dd>
	 *   none
	 * <dt><b>Complexity</b><dd>
	 *   Constant
	 */
	public Rectangle(Loc upperLeft, int width, int length) {
		super(upperLeft);		
		this.width = width;
		this.length = length;
	}

	/**
	 * Get this Rectangle's width 
	 * @return the width of the Rectangle
	 * <dt><b>Preconditions</b><dd>
	 *   none
	 * <dt><b>Postconditions</b><dd>
	 *   none
	 * <dt><b>Complexity</b><dd>
	 *   Constant
	 */
	public int getWidth() {
		return width;
	}

	/**
	 * Set this Rectangle's width to width
	 * @param width the new width
	 * @return none
	 * <dt><b>Preconditions</b><dd>
	 *   width >= 0
	 * <dt><b>Postconditions</b><dd>
	 *   this rectangle is now width column wide
	 * <dt><b>Complexity</b><dd>
	 *   Constant
	 */
	public void setWidth(int width) {
		this.width = width;
	}

	/**
	 * Get this Rectangle's length 
	 * @return the length of the Rectangle
	 * <dt><b>Preconditions</b><dd>
	 *   none
	 * <dt><b>Postconditions</b><dd>
	 *   none
	 * <dt><b>Complexity</b><dd>
	 *   Constant
	 */
	public int getLength() {
		return length;
	}

	/**
	 * Set this Rectangle's length to length
	 * @param width the new width
	 * @return none
	 * <dt><b>Preconditions</b><dd>
	 *   length >= 0
	 * <dt><b>Postconditions</b><dd>
	 *   this rectangle is now length rows long
	 * <dt><b>Complexity</b><dd>
	 *   Constant
	 */
	public void setLength(int length) {
		this.length = length;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();		
		result = prime * result + length;
		result = prime * result + width;
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Rectangle other = (Rectangle) obj;
		if (length != other.length) {
			return false;
		}
		if (width != other.width) {
			return false;
		}
		return true;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Rectangle [width=");
		builder.append(width);
		builder.append(", length=");
		builder.append(length);
		builder.append(", upperLeft=");
		builder.append(getLocation());
		builder.append("]");
		return builder.toString();
	}

	/*
	 * (non-Javadoc)
	 * @see ln5.Shape#area()
	 */
	@Override
	public double area() {
		return this.length * this.width;
	}

	/* (non-Javadoc)
	 * @see ln5.Shape#isWithin(ln5.Loc)
	 */
	@Override
	public boolean isWithin(Loc l) {
		Loc upperLeft = this.getLocation();
		return 
		  upperLeft.getRow() <= l.getRow() &&
		  upperLeft.getRow() + this.length >= l.getRow() &&
		  upperLeft.getCol() <= l.getCol() &&
		  upperLeft.getCol() + this.width >= l.getCol();			
	}

	/* (non-Javadoc)
	 * @see ln5.Shape#boundingBox()
	 */
	@Override
	public Rectangle boundingBox() {
		Loc upperLeft = this.getLocation();
		return new Rectangle(
				new Loc(upperLeft.getRow(),
						upperLeft.getCol()),
				this.width,this.length);
	}

}
