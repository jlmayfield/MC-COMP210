/**
 * Logan Mayfield
 */
package ln5;

/**
 * @author mayfieldjl
 *
 */
public abstract class AbstractShape implements Shape {

	/**
	 * The pin location for a shape
	 */
	private Loc pin; 
	
	/**
	 * Construct a shape pinned to the origin
	 * @throws none
	 * <dt><b>Preconditions</b><dd>
	 *   none
	 * <dt><b>Postconditions</b><dd>
	 *   none
	 * <dt><b>Complexity</b><dd>
	 *   Constant
	 */
	protected AbstractShape(){
		this.pin = new Loc(0,0);
	}
	
	/**
	 * Construct a shape pinned to loc
	 * @param loc the pin location
	 * @throws none
	 * <dt><b>Preconditions</b><dd>
	 *   none
	 * <dt><b>Postconditions</b><dd>
	 *   none
	 * <dt><b>Complexity</b><dd>
	 *   Constant
	 */
	protected AbstractShape(Loc loc) {
		this.pin = loc;
	}

	/**
	 * Get the pin location of the shape 
	 * @return the pin location
	 */
	public Loc getLocation() {
		return pin;
	}

	/**
	 * Set the pin location of the shape
	 * @param pin the pin to set
	 */
	public void setLocation(Loc pin) {
		this.pin = pin;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((pin == null) ? 0 : pin.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		AbstractShape other = (AbstractShape) obj;
		if (pin == null) {
			if (other.pin != null) {
				return false;
			}
		} else if (!pin.equals(other.pin)) {
			return false;
		}
		return true;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("AbstractShape [pin=");
		builder.append(pin);
		builder.append("]");
		return builder.toString();
	}

	/* (non-Javadoc)
	 * @see ln5.Shape#distanceTo(ln5.Loc)
	 */
	@Override
	public double distanceTo(Loc l) {
		return this.pin.distanceTo(l);
	}
	
	/* (non-Javadoc)
	 * @see ln5.Shape#moveTo(ln5.Loc)
	 */
	@Override
	public void moveTo(Loc l) {
		this.setLocation(l);
	}

	/* (non-Javadoc)
	 * @see ln5.Shape#area()
	 */
	@Override
	abstract public double area();
	
	/* (non-Javadoc)
	 * @see ln5.Shape#isWithin(ln5.Loc)
	 */
	@Override
	abstract public boolean isWithin(Loc l);

	/* (non-Javadoc)
	 * @see ln5.Shape#boundingBox()
	 */
	@Override
	abstract public Rectangle boundingBox();

}
