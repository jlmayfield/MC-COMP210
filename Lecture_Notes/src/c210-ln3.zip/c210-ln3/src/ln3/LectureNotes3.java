package ln3;

import java.io.PrintStream;
import java.util.Scanner;

public class LectureNotes3 {
	
	/**
	 * Compute the factorial of n
	 * @param n	 a positive integer
	 * @return the factorial of n
	 * @throws none
	 * <dt><b>Precondition</b><dd>
	 *    n >= 0
	 * <dt><b>Postcondition</b><dd>
	 *  none
	 * <dt><b>Complexity</b><dd> 	 
	 *  Linear in n
	 */
	public static int factorial(int n){
		if( n == 0 ){
			return 1;
		}
		else{
			return n * LectureNotes3.factorial(n-1);			
		}		
	}
	
	
	/**
	 * Print the string str backwards on the stream out
	 * @param out Stream where the reverse is written
	 * @param str string to be printed in reverse
	 * @throws none
	 * <dt><b>Precondition</b><dd>
	 *    none
	 * <dt><b>Postcondition</b><dd>
	 *    for non-empty str, it's contents are written (in reverse)
	 * <dt><b>Complexity</b><dd> 	 
	 *   Linear in the size of str
	 */
	public static void printRev(PrintStream out, String str){
		
		for( int i = str.length()-1 ; i >= 0; --i ){
			out.print(str.charAt(i));
		}
		
		return;
	}
	
	/**
	 * 
	 * @param in
	 * @param vowels
	 * @throws
	 * <dt><b>Preconditions</b><dd>
	 *   none
	 * <dt><b>Postconditions</b><dd>
	 *   Consumes all characters in Scanner in
	 * <dt><b>Complexity</b><dd>
	 *   Linear in the number characters in Scanner in  
	 */
	public static void collectVowels(Scanner in, StringBuilder vowels){
		
		while( in.hasNext() ){
			String nxt_line = in.next();
			for(int i = 0; i < nxt_line.length(); i++){
				char nxt_char = nxt_line.charAt(i);
				if( nxt_char == 'a' || nxt_char == 'i' || 
					nxt_char == 'e' || nxt_char == 'o' ||
					nxt_char == 'u'){
					
					vowels.append(nxt_char);
				}
			}
		}
		
		return;
	}

	public static void main(String[] args) {
		
		LectureNotes3.printRev(System.out, "racecar");
		System.out.println();
		
		StringBuilder vowels = new StringBuilder("");
		LectureNotes3.collectVowels(new Scanner(System.in),vowels);
		
		System.out.println(vowels.toString());
		
		return;
	}

}
