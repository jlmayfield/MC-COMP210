package ln3;

import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.Scanner;

import org.junit.Test;

public class LectureNotes3_Tests {

	@Test
	public void testFactorial() {
		assertEquals(1,LectureNotes3.factorial(0));
		assertEquals(1,LectureNotes3.factorial(1));
		assertEquals(2,LectureNotes3.factorial(2));
		assertEquals(120,LectureNotes3.factorial(5));
	}
	
	@Test
	public void testPrintRev(){
		ByteArrayOutputStream actual;
		
		actual = new ByteArrayOutputStream();
		LectureNotes3.printRev(new PrintStream(actual),"");
		assertEquals("",actual.toString());
		
		actual = new ByteArrayOutputStream();
		LectureNotes3.printRev(new PrintStream(actual),"hello");
		assertEquals("olleh",actual.toString());	
	}
	
	@Test
	public void testCollectVowels(){
		StringBuilder actual;
		
		actual = new StringBuilder("");		
		LectureNotes3.collectVowels(new Scanner(""), actual);
		assertEquals("",actual.toString());
		
		actual = new StringBuilder("");		
		LectureNotes3.collectVowels(new Scanner("ab c d efg432"), actual);
		assertEquals("ae",actual.toString());
	}
	

}
