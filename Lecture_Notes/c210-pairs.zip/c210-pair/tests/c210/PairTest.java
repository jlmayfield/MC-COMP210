package c210;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class PairTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testFst() {
		Pair<Integer,String> a = new Pair<Integer,String>(7,"Hell0");
		assertEquals(new Integer(7),a.fst());
	}

	@Test
	public void testSnd() {
		// the diamond <> saves space and can be used if
		// the types are clear enough that the compiler can
		// figure it out
		Pair<Integer,String> a = new Pair<>(7,"Hell0");
		assertEquals("Hell0",a.snd());
	}

	@Test
	public void testEqualsObject() {
		Pair<Integer,String> a = new Pair<Integer,String>(7,"Hell0");
		assertEquals(a,a);
		assertEquals(new Pair<Integer,String>(7,"Hell0"),a);
		
		assertTrue(a.equals(a));
		assertTrue(a.equals(new Pair<Integer,String>(7,"Hell0")));
		
		assertFalse(a.equals(null));
		assertFalse(a.equals(new Pair<Double,String>(7.0,"Hell0")));
		assertFalse(a.equals(new Pair<Integer,Double>(7,8.2)));
		assertFalse(a.equals(new Pair<Integer,String>(7,null)));
		assertFalse(a.equals(new Pair<Integer,String>(null,"Hell0")));
		assertFalse(a.equals(new Pair<Integer,String>(null,null)));
		assertFalse(a.equals(new Pair<Integer,String>(8,"Hell0")));
		assertFalse(a.equals(new Pair<Integer,String>(7,"hell0")));
	}

}
